from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
import os
from flask_migrate import Migrate

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:hagasya02@localhost/postgres'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = os.urandom(32)

db = SQLAlchemy(app)
migrate = Migrate(app, db)


from sqlalchemy import Column, Integer, String

class User(db.Model):
    id = Column(Integer, primary_key=True)
    username = Column(String(50), unique=True, nullable=False)
    password = Column(String(256), nullable=False)  # Encrypted password

def encrypt_text(text, key):
    cipher = Cipher(algorithms.AES(key), modes.CFB8())
    encryptor = cipher.encryptor()
    ciphertext = encryptor.update(text.encode()) + encryptor.finalize()
    return ciphertext

def decrypt_text(ciphertext, key):
    cipher = Cipher(algorithms.AES(key), modes.CFB8())
    decryptor = cipher.decryptor()
    text = decryptor.update(ciphertext) + decryptor.finalize()
    return text.decode()

@app.route('/user', methods=['POST'])
def example_endpoint():
    if request.is_json:
        data = request.get_json()
        username = data.get('username')
        password = data.get('password')
        status = data.get('status')
        return jsonify({"message": "Success"})
    else:
        return jsonify({"error": "Unsupported Media Type"}), 415

@app.route('/user/<username>', methods=['GET'])
def get_user(username):
    user = User.query.filter_by(username=username).first()
    if user:
        decrypted_password = decrypt_text(user.password, app.config['SECRET_KEY'])
        return jsonify({'username': user.username, 'password': decrypted_password})
    return jsonify({'message': 'User not found'}), 404

# Implement update and delete functions as needed

if __name__ == '__main__':
    db.create_all()
    app.run(debug=True)